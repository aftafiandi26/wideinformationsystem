<?php

namespace App\Console\Commands;

use App\User;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Mail;

class testCronjob extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'test:command';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command testing';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $user = User::find(226);

        Mail::send('email.birthdayMail', ['user' => $user], function ($message) use ($user) {
            $message->to($user->email)->subject('[Happy Birthday] Reminder - WIS');

            $message->from('wis_system@infinitestudios.id', 'WIS');
        });
    }
}